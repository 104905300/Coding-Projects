
-- Average rating across all hotels 
SELECT AVG(rating)
FROM hotel;

-- List the rooms that a housekeeper is assigned to
SELECT room_id, housek_id
FROM room 
WHERE (housek_id = 5);

-- List all customer that’s over 65 years old
SELECT fname, lname, age 
FROM customer 
where (age >= 65);

-- Number of booking for each hotel
SELECT COUNT(booking_id), hotel_id
FROM booking
GROUP BY hotel_id
ORDER BY hotel_id;

-- Minimum salary paid for each position
SELECT pos_name,
Min_hours_per_Week * salary_per_hour AS min_salary_per_week
FROM position;

-- List all bookings, their services and their price
SELECT SERVICE_OF_BOOKING.BOOKING_ID, HOTEL_SERVICE.SERVICE_NAME, HOTEL_SERVICE.COST as price
FROM SERVICE_OF_BOOKING
FULL OUTER JOIN HOTEL_SERVICE ON SERVICE_OF_BOOKING.SERVICE_ID = HOTEL_SERVICE.SERVICE_ID
Order by BOOKING_ID;
