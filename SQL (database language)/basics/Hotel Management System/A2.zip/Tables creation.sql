-- Hotel DB create tables SQL
CREATE TABLE customer(
  cust_id NUMBER (5), 
  fname VARCHAR (10) NOT NULL, 
  lname VARCHAR (15) NOT NULL, 
  email VARCHAR (20), 
  phone VARCHAR (10), 
  age NUMBER (2), 
  PRIMARY KEY (cust_id), 
  CHECK (age>=18)) 
;

CREATE TABLE hotel (
  hotel_id NUMBER (3),  
  address VARCHAR (50),
  city VARCHAR (20),
  state VARCHAR (15),  
  phone VARCHAR (10),  
  rating NUMBER (1),  
  PRIMARY KEY (hotel_id) ) 
;  

CREATE TABLE position (
  pos_id NUMBER (4),  
  pos_name VARCHAR(30),
  dep_name VARCHAR(30),
  min_hours_per_week NUMBER (2),  
  salary_per_hour NUMBER (5),  
  permission_level NUMBER (1),  
  hire_fire CHAR(1),  
  appoint CHAR(1),  
  room_entry CHAR(1),
  spend_budget CHAR(1),
  PRIMARY KEY (pos_id),
  CHECK (hire_fire IN ('Y', 'N')),
  CHECK (appoint IN ('Y', 'N')),
  CHECK (room_entry IN ('Y', 'N')),
  CHECK (spend_budget IN ('Y', 'N')))
;  

CREATE TABLE employee (
  emp_id NUMBER (4),  
  pos_id NUMBER (3),  
  hotel_id NUMBER (3),  
  fname VARCHAR (10),  
  lname VARCHAR (15),  
  email VARCHAR (20),  
  phone VARCHAR (10),  
  hire_date DATE,
  weekly_hours NUMBER (2),
  PRIMARY KEY (emp_id),  
  FOREIGN KEY (pos_id) REFERENCES position(pos_id),  
  FOREIGN KEY (hotel_id) REFERENCES hotel(hotel_id)) 
;

CREATE TABLE room (
  room_id NUMBER (3),  
  service_id NUMBER (3),  
  booking_id NUMBER (3),  
  hotel_id NUMBER (3),  
  floor NUMBER (2),  
  housek_id NUMBER (2),  
  occupied CHAR(1),  
  PRIMARY KEY (room_id),  
  FOREIGN KEY (hotel_id) REFERENCES hotel(hotel_id),
  CHECK (occupied IN ('Y', 'N'))) 
;  

CREATE TABLE booking (
  booking_id NUMBER (3),  
  cust_id NUMBER (5),  
  hotel_id NUMBER (3),  
  checkin DATE,  
  checkout DATE,  
  txn_date DATE,  
  PRIMARY KEY (booking_id),  
  FOREIGN KEY (cust_id) REFERENCES customer (cust_id),  
  FOREIGN KEY (hotel_id) REFERENCES hotel (hotel_id)) 
;

CREATE TABLE hotel_service (
  service_id NUMBER (3),  
  service_name VARCHAR (10),  
  cost NUMBER (4),
  room_service CHAR (1),  
  weekday_access CHAR (1),
  PRIMARY KEY (service_id),  
  CHECK (room_service IN ('Y', 'N')),
  CHECK (weekday_access IN ('Y', 'N')))
; 

CREATE TABLE service_of_booking (
  booking_id NUMBER (3) REFERENCES booking (booking_id),  
  service_id NUMBER (3) REFERENCES hotel_service (service_id),  
  PRIMARY KEY (booking_id, service_id)); 
  

-- Design changes
ALTER TABLE room 
ADD FOREIGN KEY (service_id) REFERENCES hotel_service (service_id);

ALTER TABLE room
MODIFY room_id NUMBER(5);

ALTER TABLE room 
ADD FOREIGN KEY (booking_id) REFERENCES booking (booking_id);  

ALTER TABLE customer 
ADD credit_card_number CHAR (16);

ALTER TABLE BOOKING
ADD CONSTRAINT checkoutConstraint CHECK (checkout >= checkin);

ALTER TABLE BOOKING
ADD CONSTRAINT transactionDateConstraint CHECK (txn_date <= checkin);

ALTER TABLE HOTEL
MODIFY RATING DECIMAL (2,1);

ALTER TABLE HOTEL_SERVICE
MODIFY service_name VARCHAR (30);


-- NORMALIAZTION of position table (2f to 3f)
ALTER TABLE position DROP COLUMN hire_fire;
ALTER TABLE position DROP COLUMN appoint;
ALTER TABLE position DROP COLUMN room_entry;
ALTER TABLE position DROP COLUMN spend_budget;

DELETE FROM position;

CREATE TABLE permission (
  permission_level NUMBER (1),  
  hire_fire CHAR(1),  
  appoint CHAR(1),  
  room_entry CHAR(1),
  spend_budget CHAR(1),
  PRIMARY KEY (permission_level),
  CHECK (hire_fire IN ('Y', 'N')),
  CHECK (appoint IN ('Y', 'N')),
  CHECK (room_entry IN ('Y', 'N')),
  CHECK (spend_budget IN ('Y', 'N')))
; 

ALTER TABLE position ADD FOREIGN KEY (permission_level) REFERENCES permission (permission_level);


-- add extra constraint
ALTER TABLE customer MODIFY Phone NOT NULL;
ALTER TABLE customer MODIFY credit_card_number NOT NULL;
ALTER TABLE customer MODIFY credit_card_number UNIQUE;

ALTER TABLE hotel MODIFY Address NOT NULL;
ALTER TABLE hotel MODIFY City NOT NULL;
ALTER TABLE hotel MODIFY State NOT NULL;
ALTER TABLE hotel MODIFY Phone NOT NULL;
ALTER TABLE hotel MODIFY Phone UNIQUE;
ALTER TABLE hotel MODIFY Rating NOT NULL;
ALTER TABLE hotel ADD CONSTRAINT rating_check CHECK (rating >= 1 and rating <= 5);

ALTER TABLE position MODIFY pos_name NOT NULL;
ALTER TABLE position MODIFY dep_name NOT NULL;
ALTER TABLE position MODIFY permission_level NOT NULL;

ALTER TABLE employee MODIFY pos_id NOT NULL;
ALTER TABLE employee MODIFY FNAME NOT NULL;
ALTER TABLE employee MODIFY LNAME NOT NULL;
ALTER TABLE employee MODIFY Phone NOT NULL;

ALTER TABLE room MODIFY SERVICE_ID NOT NULL;
ALTER TABLE room MODIFY hotel_id NOT NULL;
ALTER TABLE room MODIFY floor NOT NULL;
ALTER TABLE room MODIFY housek_id NOT NULL;
ALTER TABLE room ADD FOREIGN KEY (housek_id) REFERENCES employee (emp_id);  

ALTER TABLE booking MODIFY cust_id NOT NULL;
ALTER TABLE booking MODIFY hotel_id NOT NULL;
ALTER TABLE booking MODIFY checkin NOT NULL;
ALTER TABLE booking MODIFY txn_date NOT NULL;

ALTER TABLE hotel_service MODIFY cost NOT NULL;
